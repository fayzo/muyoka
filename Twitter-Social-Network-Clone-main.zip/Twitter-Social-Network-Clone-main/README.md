# Twitter-Social-Network-Clone
Create a Twitter Social Network Clone From Scratch PHP,MySQL

• Login & Sign-up Systems 

• Users Profiles

• Users Timeline

• Users Tweets

• Users Retweets

• Users Comments

• News Feeds

• Hashtags & Mention Users

• Top Trending Posts

• Posts & Images Popups

• Messages and Chat System

• Follow and Unfollow System

• Notification System

•And Much More.



---


### Steps to set up

1 Install Xampp in your local computer<br>
2 create a database with the name twitter<br>
3 import Sql from the code to your database<br>
4 Enjoy😁

